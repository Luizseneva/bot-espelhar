**Telegram Mirror (userbot)**

- **Overview**: Python script that mirrors messages (copies, not forwards) from one or more Telegram groups/channels to a destination using a user account (Telethon).

**Files**
- **Config**: [config.json](config.json)
- **Main**: [app.py](app.py)
- **Dependencies**: [requirements.txt](requirements.txt)

**Setup**
- Create a Telegram API application to get `api_id` and `api_hash`: https://my.telegram.org -> API development tools -> Create new application. Keep these values private.

**Install dependencies**
```bash
python -m pip install -r requirements.txt
```

**Configure**
Edit `config.json`:
- `api_id` and `api_hash`: from my.telegram.org
- `session_name`: name for the session file (e.g. `mirror_session`) — will create `mirror_session.session`
- `source_ids`: list of source chat IDs (integers like `-100123...`) or usernames
- `destination_id`: destination chat ID (integer or username)
- `delay_seconds`: seconds to wait between sends (anti-spam)
- `enable_logs`: true/false
- `keywords`: optional list of lowercase words; if non-empty only messages containing at least one keyword are copied

How to obtain chat IDs quickly:
- Use `@getidsbot` or inspect forwarded message links. Channel/group IDs commonly start with `-100` when numeric.

**Run**
```bash
python app.py
```
The first run will ask you to log in via your phone number and will create a session file.

**Notes & best practices**
- The script uses a user account — follow Telegram Terms of Service.
- Use conservative `delay_seconds` (e.g., 2-5s) to reduce risk of flood limits.
- If you need to mirror a very high volume, consider batching or increasing delay.
- The script catches `FloodWait` and will sleep for the required time when hit.
- Make sure the user account has permission to read source chats and send to destination.

**Limitations & cautions**
- Avoid mirroring extremely high-frequency chats without throttling.
- Do not use multiple rapid restarts to bypass FloodWait.
- Telegram may limit actions from user accounts that perform automated bulk actions; use responsibly.

**Support**
If you want: add logging to file, persistence for last-mirrored message id, or advanced filters — I can help extend.
#   b o t - t e l e g r a m  
 